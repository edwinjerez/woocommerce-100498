		<div class="entry-meta">
			<?php dara_posted_on(); ?>
		</div><!-- .entry-meta -->