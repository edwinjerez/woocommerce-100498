<?php
/**
 * Single Product title
 *
 * @see http://docs.woothemes.com/document/template-structure/
 * @package homestore
 * @version 1.6.4
 */

/* Title displayed from `Homestore::single_product_title()` */